wp.customize.controlConstructor['xirki-palette'] = wp.customize.xirkiDynamicControl.extend( {} );
