wp.customize.controlConstructor['xirki-radio-image'] = wp.customize.xirkiDynamicControl.extend( {} );
