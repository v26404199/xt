wp.customize.controlConstructor['xirki-color-palette'] = wp.customize.xirkiDynamicControl.extend( {} );
