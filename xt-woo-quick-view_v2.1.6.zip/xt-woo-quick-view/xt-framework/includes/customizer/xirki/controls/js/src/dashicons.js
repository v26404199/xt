wp.customize.controlConstructor['xirki-dashicons'] = wp.customize.xirkiDynamicControl.extend( {} );
